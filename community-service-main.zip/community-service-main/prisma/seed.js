import { PrismaClient } from '@prisma/client';

export const dosen = [
  { nidn: '00-5552-7772', nama: 'Dr. Eng. Agussalim, MT.' },
  { nidn: '00-1234-4321', nama: 'Dr. Rr. Ani Dijah Rahajoe, ST, M.Cs.' },
  { nidn: '00-1299-9921', nama: 'Dr. Mohammad Idhom, S.Kom., M.Kom' },
  { nidn: '00-6969-9696', nama: 'Dr. Gede Susrama Mas Diyasa, ST., MT., IPU' },
  { nidn: '00-1111-2255', nama: 'Dr. Basuki Rahmat, S.Si., MT' }
];

export const mahasiswa = [
  { npm: '23066020022', nama: 'Daniel Gloryo Nadirco' },
  { npm: '23066020024', nama: 'Wigananda Firdaus' },
  { npm: '23066020026', nama: 'Jamal Abdi Suseno' },
  { npm: '23066020032', nama: 'Clara Carrabyon' },
  { npm: '23066020064', nama: 'Shinta Amerta Sasana' }
];

export const pengmas = [
  {
    judul: 'Sistem Kesehatan Masyarakat Terpadu',
    ketua: { isKetua: true, nidn: '00-1234-4321', nama: 'Dr. Rr. Ani Dijah Rahajoe, ST, M.Cs.' },
    dosen_anggota: [
      { nidn: '00-1299-9921', nama: 'Dr. Mohammad Idhom, S.Kom., M.Kom' },
      { nidn: '00-6969-9696', nama: 'Dr. Gede Susrama Mas Diyasa, ST., MT., IPU' }
    ],
    mahasiswa: [
      { npm: '23066020022', nama: 'Daniel Gloryo Nadirco' },
      { npm: '23066020024', nama: 'Wigananda Firdaus' }
    ],
    anggaran: 25_000_000,
    tgl_mulai: '2025-01-03',
    tgl_selesai: '2025-06-25',
    lokasi: 'Kampung Melayu Gg. Jambu, Kec. Magersari, Kab. Mojoagung, Prov. Jawa Timur'
  },
  {
    judul: 'Algoritma Kesehatan Masyarakat Terpadu',
    ketua: { isKetua: true, nidn: '00-5552-7772', nama: 'Dr. Eng. Agussalim, MT.' },
    dosen_anggota: [{ nidn: '00-1111-2255', nama: 'Dr. Basuki Rahmat, S.Si., MT' }],
    mahasiswa: [
      { npm: '23066020032', nama: 'Clara Carrabyon' },
      { npm: '23066020064', nama: 'Shinta Amerta Sasana' }
    ],
    anggaran: 50_000_000,
    tgl_mulai: '2025-01-03',
    tgl_selesai: '2025-06-25',
    lokasi: 'Kampung Melayu Gg. Jambu, Kec. Magersari, Kab. Mojoagung, Prov. Jawa Timur'
  },
  {
    judul: 'Desain Sistem Kesehatan Masyarakat Terpadu',
    ketua: { isKetua: true, nidn: '00-1299-9921', nama: 'Dr. Mohammad Idhom, S.Kom., M.Kom' },
    dosen_anggota: [{ nidn: '00-6969-9696', nama: 'Dr. Gede Susrama Mas Diyasa, ST., MT., IPU' }],
    mahasiswa: [{ npm: '23066020026', nama: 'Jamal Abdi Suseno' }],
    anggaran: 75_000_000,
    tgl_mulai: '2025-01-03',
    tgl_selesai: '2025-06-25',
    lokasi: 'Kampung Melayu Gg. Jambu, Kec. Magersari, Kab. Mojoagung, Prov. Jawa Timur'
  },
  {
    judul: 'Perancangan Strategis Sistem Kesehatan Masyarakat Terpadu',
    ketua: { isKetua: true, nidn: '00-1234-4321', nama: 'Dr. Rr. Ani Dijah Rahajoe, ST, M.Cs.' },
    dosen_anggota: [{ nidn: '00-5552-7772', nama: 'Dr. Eng. Agussalim, MT.' }],
    mahasiswa: [
      { npm: '23066020022', nama: 'Daniel Gloryo Nadirco' },
      { npm: '23066020024', nama: 'Wigananda Firdaus' },
      { npm: '23066020032', nama: 'Clara Carrabyon' },
      { npm: '23066020064', nama: 'Shinta Amerta Sasana' }
    ],
    anggaran: 10_000_000,
    tgl_mulai: '2025-01-03',
    tgl_selesai: '2025-06-25',
    lokasi: 'Kampung Melayu Gg. Jambu, Kec. Magersari, Kab. Mojoagung, Prov. Jawa Timur'
  },
  {
    judul: 'Analisis Sistem Kesehatan Masyarakat Terpadu',
    ketua: { isKetua: true, nidn: '00-6969-9696', nama: 'Dr. Gede Susrama Mas Diyasa, ST., MT., IPU' },
    dosen_anggota: [{ nidn: '00-1111-2255', nama: 'Dr. Basuki Rahmat, S.Si., MT' }],
    mahasiswa: [{ npm: '23066020032', nama: 'Clara Carrabyon' }],
    anggaran: 86_000_000,
    tgl_mulai: '2025-01-03',
    tgl_selesai: '2025-06-25',
    lokasi: 'Kampung Melayu Gg. Jambu, Kec. Magersari, Kab. Mojoagung, Prov. Jawa Timur'
  }
];

async function seed() {
  const prisma = new PrismaClient();
  // const seedDosen = await prisma.dosen.createMany({ data: dosen });
  // console.log('🚒 | seed | seedDosen : ', seedDosen);
  // const seedMahasiswa = await prisma.mahasiswa.createMany({ data: mahasiswa });
  // console.log('🚒 | seed | seedMahasiswa : ', seedMahasiswa);
  // const seedPengmas = await prisma.pengabdianMasyarakat.createMany({
  //   data:
  // });
  const pengmasPromises = pengmas.map((item) => {
    const { ketua, dosen_anggota, mahasiswa, tgl_mulai, tgl_selesai, ...posted } = item;
    return prisma.pengabdianMasyarakat.create({
      data: {
        ...posted,
        dosen: {
          create: [ketua, ...dosen_anggota].map((dosen) => {
            return {
              isKetua: dosen.isKetua,
              dosen: { connect: { nidn: dosen.nidn } }
            };
          })
        },
        mahasiswa: {
          create: mahasiswa.map((mhs) => {
            return {
              mahasiswa: { connect: { npm: mhs.npm } }
            };
          })
        },
        tgl_mulai: new Date(tgl_mulai).toISOString(),
        tgl_selesai: new Date(tgl_selesai).toISOString()
      }
    });
  });
  const result = await Promise.all(pengmasPromises);
  console.log('🚒 | seed | seedPengmas : ', result);
}
seed();
