import { cookies } from 'next/headers';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

const protectedRoutes = [
  '/',
  '/dosen',
  '/dosen-laporan',
  '/keseluruhan-laporan',
  '/mahasiswa',
  '/pengabdian-masyarakat',
  '/pengabdian-masyarakat-laporan',
  '/pengabdian-masyarakat-luaran'
];

const publicRoutes = ['/signin', '/signup'];

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  const isProtectedRoute = protectedRoutes.includes(path);
  const isPublicRoute = publicRoutes.includes(path);
  const cookieStore = await cookies();
  const user = cookieStore.get('user');
  if (isProtectedRoute && !user) {
    return NextResponse.redirect(new URL('/signin', request.url));
  }
  if (isPublicRoute && user) {
    return NextResponse.redirect(new URL('/', request.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: [
    '/',
    '/signin',
    '/signup',
    '/dosen',
    '/dosen-laporan',
    '/keseluruhan-laporan',
    '/mahasiswa',
    '/pengabdian-masyarakat',
    '/pengabdian-masyarakat-laporan',
    '/pengabdian-masyarakat-luaran'
  ]
};
