export * from './pengabdian-masyarakat.type';
