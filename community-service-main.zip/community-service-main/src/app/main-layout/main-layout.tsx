'use client';

import { AppSidebar } from '@/components/app-sidebar';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import Cookie from 'js-cookie';
import { createContext, useContext } from 'react';
import type { User } from '../api/auth/signup/type';

type MainLayout = Readonly<{
  children: React.ReactNode;
}>;

type GlobalContextData = {
  user?: User;
};

const GlobalContext = createContext<GlobalContextData>({});

export const useUserContext = () => useContext(GlobalContext);

export const MainLayout = ({ children }: MainLayout) => {
  const user = JSON.parse(Cookie.get('user')!) as User;

  return (
    <SidebarProvider defaultOpen>
      <GlobalContext.Provider value={{ user }}>
        <AppSidebar />
        <SidebarInset>
          <header className='h-12 flex shrink-0 items-center gap-2'>
            <div className='flex items-center gap-2 px-4'>
              <SidebarTrigger className='-ml-1' />
              <BreadcrumbSeparator className='hidden md:block' />
              <Breadcrumb>
                <BreadcrumbList>
                  <BreadcrumbItem className='hidden md:block'>
                    <BreadcrumbLink href='/'>Sistem Informasi Pengabdian Masyarakat</BreadcrumbLink>
                  </BreadcrumbItem>
                  {/* <BreadcrumbSeparator className='hidden md:block' />
              <BreadcrumbItem>
                <BreadcrumbPage>Data Fetching</BreadcrumbPage>
              </BreadcrumbItem> */}
                </BreadcrumbList>
              </Breadcrumb>
            </div>
          </header>
          <div className='px-4 pb-4'>{children}</div>
        </SidebarInset>
      </GlobalContext.Provider>
    </SidebarProvider>
  );
};
