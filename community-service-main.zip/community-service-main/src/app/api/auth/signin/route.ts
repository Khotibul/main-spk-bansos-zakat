import prisma from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { type NextRequest, NextResponse } from 'next/server';
import type { Credentials } from './type';

const ERR_MSG = 'Email atau Password tidak sesuai';
export async function signin({ email, password }: Credentials) {
  try {
    const user = await prisma.user.findFirst({
      where: { email }
    });
    if (!user) throw ERR_MSG;
    const { password: storedPassword, ...kept } = user;
    const passwordMatch = await bcrypt.compare(password, storedPassword);
    if (!passwordMatch) throw ERR_MSG;
    return kept;
  } catch (error) {
    return error;
  }
}

export async function POST(request: NextRequest) {
  const body = (await request.json()) as Credentials;
  const result = await signin(body);
  if (typeof result === 'string') {
    return NextResponse.json({ message: result }, { status: 401 });
  }
  const cookieStore = await cookies();
  cookieStore.set('user', JSON.stringify(result));
  return NextResponse.json(result);
}
