import prisma from '@/lib/prisma';
import type { User } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { type NextRequest, NextResponse } from 'next/server';

export async function signup(data: User) {
  const { password, ...kept } = data;
  const salt = await bcrypt.genSalt(10);
  const saltedPassword = await bcrypt.hash(password, salt);
  return prisma.user.create({
    data: { password: saltedPassword, ...kept },
    select: { id: true, email: true, username: true, role: true }
  });
}

export async function POST(request: NextRequest) {
  const body = (await request.json()) as User;
  const result = await signup(body);
  if (typeof result === 'string') {
    return NextResponse.json({ message: result }, { status: 400 });
  }
  const cookieStore = await cookies();
  cookieStore.set('user', JSON.stringify(result));
  return NextResponse.json(result);
}
