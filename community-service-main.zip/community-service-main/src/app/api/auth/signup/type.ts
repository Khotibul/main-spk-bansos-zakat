import type { UserRole } from '@prisma/client';

export type User = {
  email: string;
  username: string;
  role: UserRole;
  password: string;
};
