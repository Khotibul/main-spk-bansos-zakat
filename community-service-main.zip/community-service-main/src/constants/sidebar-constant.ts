import {
  BookMarked,
  Calendar,
  FileCheck2,
  FileOutput,
  GraduationCap,
  Home,
  Inbox,
  LandPlot,
  ScrollText,
  Search,
  Settings,
  UserRoundCheck,
  UsersRound
} from 'lucide-react';

export const MAIN_SIDEBAR_CONSTANTS = [
  {
    title: 'Dashboard',
    url: '/',
    icon: Home
  },
  {
    title: 'Dosen',
    url: '/dosen',
    icon: GraduationCap
  },
  {
    title: 'Mahasiswa',
    url: '/mahasiswa',
    icon: UsersRound
  },
  {
    title: 'Pengabdian Masyarakat',
    url: '/pengabdian-masyarakat',
    icon: LandPlot
  }
];

export const REPORT_SIDEBAR_CONSTANTS = [
  {
    title: 'Laporan Dosen',
    url: '/dosen-laporan',
    icon: BookMarked
  },
  {
    title: 'Laporan Pengabdian Masyarakat',
    url: '/pengabdian-masyarakat-laporan',
    icon: FileCheck2
  },
  {
    title: 'Luaran Pengabdian Masyarakat',
    url: '/pengabdian-masyarakat-luaran',
    icon: FileOutput
  },
  {
    title: 'Laporan Keseluruhan',
    url: '/keseluruhan-laporan',
    icon: ScrollText
  }
];
