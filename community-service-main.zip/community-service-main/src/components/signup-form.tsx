'use client';
import type { User } from '@/api/auth/signup/type';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { GraduationCap, Ribbon, UsersRound } from 'lucide-react';
import { redirect } from 'next/navigation';
import { useForm } from 'react-hook-form';

export function SignupForm() {
  const { register, handleSubmit, setValue, watch } = useForm<User>();
  const wRole = watch('role');

  async function onSubmit(data: User) {
    const response = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const responseData = await response.json();
    redirect('/');
  }

  return (
    <Card className='mx-auto max-w-sm'>
      <CardHeader>
        <div className='flex gap-3 mb-4'>
          <div className='flex aspect-square size-8 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground'>
            <Ribbon className='size-5' />
          </div>
          <div className='grid flex-1 text-left text-sm leading-tight'>
            <span className='-ml-[0.1rem] truncate font-semibold'>SIDIMAS</span>
            <span className='truncate text-xs'>SI Pengabdian Masyarakat</span>
          </div>
        </div>
        <CardTitle className='text-2xl'>Sign up</CardTitle>
        <CardDescription>Create an account, let us know who you are.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className='grid gap-4'>
            <div className='grid gap-2'>
              <Label htmlFor='email'>Email</Label>
              <Input id='email' type='email' placeholder='m@example.com' required {...register('email')} />
            </div>
            <div className='grid gap-2'>
              <Label htmlFor='email'>Username</Label>
              <Input id='email' minLength={3} required {...register('username')} />
            </div>
            <div className='grid gap-2'>
              <Label htmlFor='password'>Password</Label>
              <Input id='password' type='password' required {...register('password')} />
            </div>
            <Label htmlFor='role' className='-mb-2 '>
              Role
            </Label>
            <div id='role' className='flex gap-2'>
              <Button
                type='button'
                onClick={() => setValue('role', 'DOSEN')}
                variant={wRole === 'DOSEN' ? 'default' : 'outline'}
                className='flex-1'
              >
                <GraduationCap />
                Dosen
              </Button>
              <Button
                type='button'
                onClick={() => setValue('role', 'MAHASISWA')}
                variant={wRole === 'MAHASISWA' ? 'default' : 'outline'}
                className='flex-1'
              >
                <UsersRound />
                Mahasiswa
              </Button>
            </div>
            <Button type='submit' className='w-full'>
              Sign up
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
